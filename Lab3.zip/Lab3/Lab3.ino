#define MAX 2

float pomiary[4], P = 1, I , D = 0.7, PredkoscZadana, calka, uchyb_poprzedni, uchyb;
unsigned long czas, pomiar, czasI, czasPocz = millis();
int numer;
void setup() {
  pinMode(2,INPUT_PULLUP);
  pinMode(5,OUTPUT);
  attachInterrupt(digitalPinToInterrupt(2),przerwanie,CHANGE);
  Serial.begin(9600);
}

float predkoscMierzona(){
  float suma = 0;
  for(int i = 0; i < 4; i++){
    suma += pomiary[i];
  }
  return ((suma == 0) || (suma > 2000)) ? 0 : 4115.2/suma;
  
}
void przerwanie(){
  czas = millis();
  pomiary[numer] = int (czas - pomiar);
  pomiar = czas;
  numer ++;
  if(numer > 3) 
    numer = 0;
}
void PID(float zadana){
  float wypelnienie, pochodna, dt;

  czasI = micros();
  uchyb_poprzedni = uchyb;
  uchyb = zadana - predkoscMierzona();
  
  dt = (micros() - czasI) / 1000000.0;
  calka += dt * uchyb;

  if (calka > MAX){
    calka = MAX;
  }
  if(calka < -MAX){
    calka = -MAX;
  }

  pochodna = (uchyb - uchyb_poprzedni) / dt;
  wypelnienie = uchyb * P + calka * I + D * pochodna;
  if(wypelnienie > 255){
    wypelnienie = 255;
  }
  if(wypelnienie < 0){
    wypelnienie = 0;
  }
  analogWrite(5,wypelnienie);
}
void loop() {
  unsigned long t = millis() - czasPocz;
  t = t % 20000;

  czas = millis();
  if(czas - pomiar > 300){
    pomiary[numer] = 999;
    numer++;
    
    if(numer > 3) 
      numer = 0;
    
    pomiar = czas;
  }
  
  if(Serial.available()){
    char cCo = Serial.read();
    switch (cCo){
      case 'P':
        P = Serial.parseInt();
        break;
      case 'I':
        I = Serial.parseFloat();
        break;
      case 'D':
        D = Serial.parseFloat(); 
        break;
      case 's':
        PredkoscZadana = Serial.parseInt();
        break;
    }
  }
  if (t > 10000 ){
    PredkoscZadana = 130;
  }
  if (t > 15000 ){
    PredkoscZadana = 60;
  }
  if (t > 19500){
    PredkoscZadana = 20;

  }
  I = PredkoscZadana * 17;
  PID(PredkoscZadana);
  Serial.print("0");
  Serial.print("\t");
  Serial.print(PredkoscZadana);
  Serial.print("\t");
  Serial.println(predkoscMierzona());

  
}
