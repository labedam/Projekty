%+=========================M1=======================+
S = 788;
ms = 280 + 0.4 * S; 
mu = 35 + 0.05 * S;         
ks = (18 + 0.02 * S) * 1e3;  
kt = (150 + 0.05 * S) * 1e3; 
cs = (1.4 + 0.002 * S) * 1e3;
ct = (0.4 + 0.001 * S) * 1e3;

A = [0,       1,       0,      -1;
    -ks/ms, -cs/ms,   0,       cs/ms;
     0,       0,       0,       1;
     ks/mu,   cs/mu,  -kt/mu,  -(cs+ct)/mu];

    B = [0;1/ms; 0;-1/mu];

    E = [0,  -1,     0;
         0,   cs/ms, 0;
         0,   0,    0;
         kt/mu,  -cs/mu, -1];

    C = [0, 1, 0, 0;  
         0, 0, 1, 0; 
         1, 0, 0, 0]; 

    D = [0; 0; 0];
    B_w = [B, E];
    D_w = [D, zeros(3,3)];
    C_wybrane = [0, 1, 0, 0; 0, 0, 1, 0];

%+=========================M2=======================+
    Sterowalnosc = ctrb(A, B);
    Rank_sterowalnosc = rank(Sterowalnosc);
    
    Obserwowalnosc = obsv(A,C_wybrane);
    Rank_obserwowalnosc = rank(Obserwowalnosc);

%+=========================M3=======================+
% Wyznaczone bieguny
p1 = -30 + 22i;
p2 = -30 - 22i;
p3 = -100;
p4 = -120;
poles = [p1, p2, p3, p4];

% Obliczenie wzmocnienia K
K = place(A, B, poles);

%+=========================M4=======================+
%lqr
Q = diag([1e9, 1, 1e9, 1]);
R = 1e-4;

k_lqr = lqr(A, B, Q, R);

 %Pobranie danych z kontenera 'out' dla komfort
t = out.przyspieszenie.time;

sygnaly = out.przyspieszenie.signals(1).values;
sygnalybieguny = out.przyspieszenie.signals(2).values;
sygnalypasywny = out.przyspieszenie.signals(3).values;

a_body = sygnaly; 
a_bodybieguny = sygnalybieguny; 
a_bodypasywny = sygnalypasywny;

% Obliczanie Komfort
komfort_wynik = sqrt(mean(a_body.^2));
komfort_wynikb = sqrt(mean(a_bodybieguny.^2));
komfort_wynikp = sqrt(mean(a_bodypasywny.^2));

% Print Komfort
fprintf('Wartość komfort dla regulatora lqr: %f\n', komfort_wynik)
fprintf('Wartość komfort dla regulatora bieguny: %f\n', komfort_wynikb)
fprintf('Wartość komfort dla regulatora pasywny: %f\n', komfort_wynikp)

% Pobranie danych z kontenera 'out' dla prowadzenia

tire_deflection = out.lqr_dane.signals(2).values;
tire_deflectionbieguny = out.bieguny.signals(2).values;
tire_deflectionpasywny = out.pasywny.signals(2).values;


% Obliczamy prowadzenie
rms_prowadzenie = sqrt(mean(tire_deflection.^2));
rms_prowadzenieb = sqrt(mean(tire_deflectionbieguny.^2));
rms_prowadzeniep = sqrt(mean(tire_deflectionpasywny.^2));

fprintf('Wartość Prowadzenie lqr: %f\n', rms_prowadzenie);
fprintf('Wartość Prowadzenie biguny: %f\n', rms_prowadzenieb);
fprintf('Wartość Prowadzenie pasywny: %f\n', rms_prowadzeniep);

%skok zawieszenia
s_lqr = max(abs(out.lqr_dane.signals(3).values));
s_pp  = max(abs(out.bieguny.signals(3).values));
s_pas = max(abs(out.pasywny.signals(3).values));


fprintf('Metryka: \t\t LQR \t\t PP \t\t Pasywny\n');
fprintf('Komfort (RMS): \t %.4f \t %.4f \t %.4f\n', komfort_wynik, komfort_wynikb, komfort_wynikp);
fprintf('Prow. (RMS): \t %.4f \t %.4f \t %.4f\n', rms_prowadzenie, rms_prowadzenieb, rms_prowadzeniep);
fprintf('Skok (MAX): \t %.4f \t %.4f \t %.4f\n', s_lqr, s_pp, s_pas);

%+=========================M5=======================+
% Rozszerzenie modelu o integrator (M5)
Ci = [1, 0, 0, 0]; 
A_aug = [A, zeros(4,1); -Ci, 0];
B_aug = [B; 0];

% Nowe bieguny (5 zamiast 4)
poles_aug = [poles, -5]; 
K_aug = place(A_aug, B_aug, poles_aug);

% ==================M6==============================
poles_obs = 4 * poles; 

L = place(A', C', poles_obs)';

A_obs = A - L * C;
B_obs = [B_w, L];             
C_obs = eye(4);             
D_obs = zeros(4, size(B_obs, 2));