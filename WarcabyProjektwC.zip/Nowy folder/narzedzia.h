#ifndef NARZEDZIA
#define NARZEDZIA

#include "definicje.h"
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>

ruch_na_liscie* legalne_ruchy(plansza_gry* plansza);
void wypisz_legalne_ruchy(plansza_gry* plansza);
void zabij_ruchy_na_liscie(ruch_na_liscie* glowa);

bool sprawdz(plansza_gry* plansza, int kolumna, int wiersz, bool is_damka)
{
    int kierunki[4][2] = { {1, 1}, {1, -1}, {-1, 1}, {-1, -1} };

    for (int i = 0; i < 4; ++i)
    {
        int dx = kierunki[i][0];
        int dy = kierunki[i][1];

        for (int d = 1; d < SZEROKOSC_POLA; ++d)
        {
            int new_kolumna = kolumna + d * dx;
            int new_wiersz = wiersz + d * dy;

            if (new_kolumna >= 0 && new_kolumna < SZEROKOSC_POLA && new_wiersz >= 0 && new_wiersz < WYSOKOSC_POLA)
            {
                if (plansza->pole[new_kolumna][new_wiersz] == PUSTE)
                {
                    return true;
                }
                else if (plansza->pole[new_kolumna][new_wiersz] != PUSTE && plansza->pole[new_kolumna][new_wiersz] != plansza->gracz_na_ruchu)
                {
                    if (new_kolumna + dx >= 0 && new_kolumna + dx < SZEROKOSC_POLA && new_wiersz + dy >= 0 && new_wiersz + dy < WYSOKOSC_POLA)
                    {
                        if (plansza->pole[new_kolumna + dx][new_wiersz + dy] == PUSTE)
                        {
                            return true;
                        }
                    }
                }
                else
                {
                    break;
                }
            }
            else
            {
                break;
            }
        }
    }

    return false;
}



// Funkcja wypisująca planszę
void wypisz(plansza_gry* poletko)
{
    printf("  +");
    for (int i = 0; i < 3 * SZEROKOSC_POLA; printf("-"), i++);
    printf("+\n");
    for (int i = 0; i < WYSOKOSC_POLA; i++)
    {
        printf("%2d|", i);
        for (int j = 0; j < SZEROKOSC_POLA; j++)
        {
            switch (poletko->pole[j][i])
            {
            case PUSTE:
                printf(" . ");
                break;
            case BIALY:
                printf(" o ");
                break;
            case CZARNY:
                printf(" x ");
                break;
            case BIALY_DAMKA:
                printf(" 0 ");
                break;
            case CZARNY_DAMKA:
                printf(" X ");
                break;
            }
        }
        printf("|\n");
    }
    printf("  +");
    for (int i = 0; i < 3 * SZEROKOSC_POLA; printf("-"), i++);
    printf("+\n");
    printf("   ");
    for (int i = 0; i < SZEROKOSC_POLA; i++)
        printf(" %d ", i);
    printf("\n");

    // Wypisywanie gracza na ruchu
    wypisz_legalne_ruchy(poletko);
}

// Funkcja ustawiająca stan początkowy planszy
void ustaw_stan_poczatkowy(plansza_gry* poletko)
{
    // Ustawianie stanu początkowego
    for (int i = 0; i < SZEROKOSC_POLA; i++)
        for (int j = 0; j < WYSOKOSC_POLA; j++)
            poletko->pole[i][j] = PUSTE;

    // Białe pionki na górze planszy
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < SZEROKOSC_POLA; j++)
            if ((i + j) % 2 == 1)
                poletko->pole[j][i] = BIALY;

    // Czarne pionki na dole planszy
    for (int i = WYSOKOSC_POLA - 1; i >= WYSOKOSC_POLA - 3; i--)
        for (int j = 0; j < SZEROKOSC_POLA; j++)
            if ((i + j) % 2 == 1)
                poletko->pole[j][i] = CZARNY;

    // Ustawienie gracza na ruchu
    poletko->gracz_na_ruchu = RUCH_BIALEGO;
}

plansza_gry wykonaj_ruch(plansza_gry* plansza, ruch posuniecie)
{
    if (posuniecie.na_pole.kolumna < 0 || posuniecie.na_pole.kolumna >= SZEROKOSC_POLA)
        return *plansza; // Wróć do początku, jeśli ruch jest niepoprawny

    if (posuniecie.na_pole.wiersz < 0 || posuniecie.na_pole.wiersz >= WYSOKOSC_POLA)
        return *plansza; // Wróć do początku, jeśli ruch jest niepoprawny

    if (plansza->pole[posuniecie.na_pole.kolumna][posuniecie.na_pole.wiersz] != PUSTE)
        return *plansza; // Wróć do początku, jeśli ruch jest niepoprawny

    plansza_gry nowe = *plansza;
    nowe.pole[posuniecie.na_pole.kolumna][posuniecie.na_pole.wiersz] = nowe.pole[posuniecie.z_pola.kolumna][posuniecie.z_pola.wiersz];
    nowe.pole[posuniecie.z_pola.kolumna][posuniecie.z_pola.wiersz] = PUSTE;
    nowe.gracz_na_ruchu = (nowe.gracz_na_ruchu == RUCH_BIALEGO) ? RUCH_CZARNEGO : RUCH_BIALEGO;

    typ_pola przeciwnik = (nowe.gracz_na_ruchu == RUCH_BIALEGO) ? BIALY : CZARNY;
    typ_pola ja = (nowe.gracz_na_ruchu == RUCH_BIALEGO) ? CZARNY : BIALY;

    // Sprawdzenie, czy pionek doszedł do końca planszy i staje się damką
    if (nowe.gracz_na_ruchu == RUCH_BIALEGO && posuniecie.na_pole.wiersz == 0)
    {
        nowe.pole[posuniecie.na_pole.kolumna][posuniecie.na_pole.wiersz] = BIALY_DAMKA;
    }
    else if (nowe.gracz_na_ruchu == RUCH_CZARNEGO && posuniecie.na_pole.wiersz == WYSOKOSC_POLA - 1)
    {
        nowe.pole[posuniecie.na_pole.kolumna][posuniecie.na_pole.wiersz] = CZARNY_DAMKA;
    }

    // Sprawdzenie, czy doszło do bicia
    if (abs(posuniecie.na_pole.kolumna - posuniecie.z_pola.kolumna) == 2 && abs(posuniecie.na_pole.wiersz - posuniecie.z_pola.wiersz) == 2)
    {
        // Obliczenie pozycji zbitego pionka
        int kolumna_zbitego = (posuniecie.na_pole.kolumna + posuniecie.z_pola.kolumna) / 2;
        int wiersz_zbitego = (posuniecie.na_pole.wiersz + posuniecie.z_pola.wiersz) / 2;

        // Usunięcie zbitego pionka
        if (nowe.pole[kolumna_zbitego][wiersz_zbitego] != przeciwnik)
            return *plansza; // Wróć do początku, jeśli ruch jest niepoprawny

        nowe.pole[kolumna_zbitego][wiersz_zbitego] = PUSTE;
    }

    return nowe;
}



// Funkcja zwalniająca pamięć zajętą przez listę ruchów
void zabij_ruchy_na_liscie(ruch_na_liscie* glowa)
{
    if (glowa)
    {
        ruch_na_liscie* temp = glowa->nastepny;
        free(glowa);
        zabij_ruchy_na_liscie(temp);
    }
}


// Funkcja dodająca ruch do listy
void dodaj_ruch_do_listy(ruch* posuniecie, ruch_na_liscie** lista)
{
    ruch_na_liscie* nowy_ruch = (ruch_na_liscie*)malloc(sizeof(ruch_na_liscie));
    if (nowy_ruch)
    {
        nowy_ruch->ruch = *posuniecie;
        nowy_ruch->nastepny = *lista;
        *lista = nowy_ruch;
    }
    else
    {
        // Obsługa błędu alokacji pamięci
        fprintf(stderr, "Błąd alokacji pamięci dla ruchu.\n");
        exit(EXIT_FAILURE);
    }
}

void dodaj_bicia(plansza_gry* plansza, int kolumna, int wiersz, ruch* posuniecie, ruch_na_liscie** lista)
{
    typ_pola przeciwnik = (plansza->gracz_na_ruchu == RUCH_BIALEGO) ? CZARNY : BIALY;
    bool is_damka = (plansza->pole[kolumna][wiersz] == BIALY_DAMKA || plansza->pole[kolumna][wiersz] == CZARNY_DAMKA);
    int dist = is_damka ? SZEROKOSC_POLA : 2;

    for (int dx = -1; dx <= 1; dx += 2)
    {
        for (int dy = -1; dy <= 1; dy += 2)
        {
            for (int d = 1; d <= dist; d++)
            {
                int new_kolumna = kolumna + d * dx;
                int new_wiersz = wiersz + d * dy;

                if (new_kolumna >= 0 && new_kolumna < SZEROKOSC_POLA && new_wiersz >= 0 && new_wiersz < WYSOKOSC_POLA && plansza->pole[kolumna + d * dx][wiersz + d * dy] == przeciwnik && plansza->pole[new_kolumna][new_wiersz] == PUSTE)
                {
                    posuniecie->na_pole.kolumna = new_kolumna;
                    posuniecie->na_pole.wiersz = new_wiersz;
                    plansza->pole[kolumna + d * dx][wiersz + d * dy] = PUSTE;
                    dodaj_bicia(plansza, new_kolumna, new_wiersz, posuniecie, lista);
                    plansza->pole[kolumna + d * dx][wiersz + d * dy] = przeciwnik;
                }
                else if (is_damka && new_kolumna >= 0 && new_kolumna < SZEROKOSC_POLA && new_wiersz >= 0 && new_wiersz < WYSOKOSC_POLA && plansza->pole[new_kolumna][new_wiersz] == PUSTE)
                {
                    posuniecie->na_pole.kolumna = new_kolumna;
                    posuniecie->na_pole.wiersz = new_wiersz;
                    dodaj_bicia(plansza, new_kolumna, new_wiersz, posuniecie, lista);
                }
            }
        }
    }
    if (!is_damka)
        dodaj_ruch_do_listy(posuniecie, lista);
}


ruch_na_liscie* legalne_ruchy(plansza_gry* plansza)
{
    ruch_na_liscie* glowa = NULL;
    typ_pola ja = (plansza->gracz_na_ruchu == RUCH_BIALEGO) ? BIALY : CZARNY;
    typ_pola przeciwnik = (plansza->gracz_na_ruchu == RUCH_BIALEGO) ? CZARNY : BIALY;
    typ_pola damka = (plansza->gracz_na_ruchu == RUCH_BIALEGO) ? BIALY_DAMKA : CZARNY_DAMKA;

    for (int kolumna = 0; kolumna < SZEROKOSC_POLA; kolumna++)
    {
        for (int wiersz = 0; wiersz < WYSOKOSC_POLA; wiersz++)
        {
            if ((plansza->pole[kolumna][wiersz] == ja && plansza->pole[kolumna][wiersz] != damka) || (plansza->pole[kolumna][wiersz] == damka && !damka))
            {
                bool is_damka = plansza->pole[kolumna][wiersz] == damka;
                int dist = is_damka ? SZEROKOSC_POLA : 1;

                for (int i = 0; i < 4; i++)
                {
                    int dx = kierunki[i][0];
                    int dy = kierunki[i][1];

                    for (int d = 1; d <= dist; d++)
                    {
                        int new_kolumna = kolumna + d * dx;
                        int new_wiersz = wiersz + d * dy;

                        if (new_kolumna >= 0 && new_kolumna < SZEROKOSC_POLA && new_wiersz >= 0 && new_wiersz < WYSOKOSC_POLA)
                        {
                            if (plansza->pole[new_kolumna][new_wiersz] == PUSTE)
                            {
                                ruch posuniecie;
                                posuniecie.z_pola.kolumna = kolumna;
                                posuniecie.z_pola.wiersz = wiersz;
                                posuniecie.na_pole.kolumna = new_kolumna;
                                posuniecie.na_pole.wiersz = new_wiersz;

                                dodaj_ruch_do_listy(&posuniecie, &glowa);
                            }
                        }
                    }
                }
            }
        }


// Funkcja wypisująca legalne ruchy
void wypisz_legalne_ruchy(plansza_gry* plansza)
{
    ruch_na_liscie* legalne_ruchy_list = legalne_ruchy(plansza);
    ruch_na_liscie* current = legalne_ruchy_list;

    printf("Legalne ruchy dla gracza:\n");
    while (current != NULL)
    {
        if (plansza->pole[current->ruch.z_pola.kolumna][current->ruch.z_pola.wiersz] == plansza->gracz_na_ruchu)
        {
            printf("Ruch z (%d, %d) do (%d, %d)\n", current->ruch.z_pola.kolumna, current->ruch.z_pola.wiersz, current->ruch.na_pole.kolumna, current->ruch.na_pole.wiersz);
        }
        current = current->nastepny;
    }

    zabij_ruchy_na_liscie(legalne_ruchy_list);
}


#endif 
 




