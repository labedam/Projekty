#include "definicje.h"
#include "narzedzia.h"
#include "ocena.h"
#include "negamax.h"
#include <stdio.h>

int main()
{
    plansza_gry plansza;
    ustaw_stan_poczatkowy(&plansza);

    while (1)
    {
        wypisz(&plansza);

        if (plansza.gracz_na_ruchu == RUCH_BIALEGO)
        {
            printf("Ruch białego gracza:\n");
            int glebokosc_bialego = 2; // Ustaw głębokość dla białego gracza
            ruch_na_liscie* ruchy_bialego = legalne_ruchy(&plansza);
            ruch_na_liscie* ptr_bialego = ruchy_bialego;
            int ruch_bialego = negamax(&plansza, glebokosc_bialego);
            plansza = wykonaj_ruch(&plansza, ptr_bialego->ruch);
            zabij_ruchy_na_liscie(ptr_bialego);
        }
        else
        {
            printf("Ruch czarnego gracza:\n");
            int glebokosc_czarnego = 2; // Ustaw głębokość dla czarnego gracza
            ruch_na_liscie* ruchy_czarnego = legalne_ruchy(&plansza);
            ruch_na_liscie* ptr_czarnego = ruchy_czarnego;
            int ruch_czarnego = negamax(&plansza, glebokosc_czarnego);
            plansza = wykonaj_ruch(&plansza, ptr_czarnego->ruch);
            zabij_ruchy_na_liscie(ptr_czarnego);
        }
        int wynik = ocen_pozycje(&plansza);
        if (wynik == ZWYCIESTWO)
        {
            printf("Gracz na ruchu wygrywa!\n");
            break;
        }
        else if (wynik == PORAZKA)
        {
            printf("Gracz na ruchu przegrywa!\n");
            break;
        }
    }
    return 0;
}
