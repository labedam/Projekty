#ifndef DEFINICJE

#define DEFINICJE

#define SZEROKOSC_POLA 12
#define WYSOKOSC_POLA 12

const int PORAZKA = -(SZEROKOSC_POLA * WYSOKOSC_POLA + 10);
const int ZWYCIESTWO = -PORAZKA;

#include <limits.h>

typedef enum { PUSTE, BIALY, CZARNY, BIALY_DAMKA, CZARNY_DAMKA } typ_pola;
typedef enum { RUCH_BIALEGO, RUCH_CZARNEGO } ruch_gracza;

typedef struct
{
    typ_pola pole[SZEROKOSC_POLA][WYSOKOSC_POLA];
    ruch_gracza gracz_na_ruchu;
} plansza_gry;

typedef struct
{
    char wiersz, kolumna;
} pole;

typedef struct
{
    pole na_pole;
    pole z_pola;
} ruch;

typedef struct element
{
    ruch ruch;
    struct element* nastepny;
} ruch_na_liscie;

int kierunki[4][2] = { {1, -1}, {-1, 1}, {-1, -1}, {1, 1} };

#endif