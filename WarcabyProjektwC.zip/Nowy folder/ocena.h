#ifndef OCENA

#define OCENA

#include "definicje.h"

int ocen_pozycje(plansza_gry* plansza)
{
    int kolka = 0, krzyzyki = 0, biale_damy = 0, czarne_damy = 0, puste = 0;
    for(int kolumna = 0; kolumna < SZEROKOSC_POLA; kolumna++)
        for(int wiersz = 0; wiersz < WYSOKOSC_POLA; wiersz++)
            switch(plansza->pole[kolumna][wiersz])
            {
                case BIALY:
                    kolka++; break;
                case CZARNY:
                    krzyzyki++; break;
                case BIALY_DAMKA:
                    biale_damy++; break;
                case CZARNY_DAMKA:
                    czarne_damy++; break;
                case PUSTE:
                    puste++; break;
            }
    if (!puste)
        return plansza->gracz_na_ruchu == RUCH_BIALEGO ? ((kolka + 3*biale_damy) > (krzyzyki + 3*czarne_damy) ? ZWYCIESTWO : ((kolka + 3*biale_damy) < (krzyzyki + 3*czarne_damy) ? PORAZKA : 0)) : ((kolka + 3*biale_damy) < (krzyzyki + 3*czarne_damy) ? ZWYCIESTWO : ((kolka + 3*biale_damy) > (krzyzyki + 3*czarne_damy) ? PORAZKA : 0));
    return (plansza->gracz_na_ruchu == RUCH_BIALEGO ? (kolka + 3*biale_damy) - (krzyzyki + 3*czarne_damy) : (krzyzyki + 3*czarne_damy) - (kolka + 3*biale_damy));
}

#endif